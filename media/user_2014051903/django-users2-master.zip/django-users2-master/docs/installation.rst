============
Installation
============

At the command line::

    $ easy_install django-users2

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv django-users2
    $ pip install django-users2