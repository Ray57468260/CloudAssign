========
Usage
========

To use django-users2 in a project::

    import django-users2