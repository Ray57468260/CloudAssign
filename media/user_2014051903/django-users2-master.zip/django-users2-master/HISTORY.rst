.. :changelog:

History
-------

0.1.0 (2014-09-25)
++++++++++++++++++

* First release on PyPI.
